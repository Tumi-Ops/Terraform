import os
import json
import boto3
import smtplib
from datetime import datetime
from email.message import EmailMessage
from boto3.dynamodb.conditions import Attr
from botocore.exceptions import ClientError

dynamodb = boto3.resource("dynamodb").Table(os.environ["TABLE_NAME"])
client = boto3.client("bedrock-runtime", "us-east-1")
MODEL_ID = "amazon.nova-lite-v1:0"
secret_name = "dev/email-creds"
session = boto3.session.Session()
secrets_client = session.client('secretsmanager')


def lambda_handler(event, context):
    birthday_info = get_today_birthdays()

    if not birthday_info:
        return {
            'statusCode': 200,
            'body': json.dumps('No birthdays today')
        }

    for x in birthday_info:
        message = generate_message(x["recipient_name"],
                                   x["relationship"], x["sender_name"])
        send_email(x["email"], x["relationship"], message)

        mark_as_wished(x["email"], x["created_at"])

    return {
        'statusCode': 200,
        'body': json.dumps('Birthdays Wished!')
    }

def get_today_birthdays():
    today_month_day = datetime.today().strftime("%m-%d")

    response = dynamodb.scan(
    FilterExpression=Attr('month_day').eq(today_month_day) &
                     Attr("wished").ne(True)
    )
    items = response['Items']

    return items

def generate_message(recipient_name, relationship, sender_name):
    inference_config = {
        "maxTokens": 200,
        "temperature": 0.8,
        "topP": 0.9
    }

    messages = [{
            "role": "user",
            "content": [{
                "text": f"Write a short, warm birthday email.\n"
                    f"To: {recipient_name}\n"
                    f"From: {sender_name}\n"
                    f"Relationship: My {relationship}\n"
                    f"Tone: friendly, heartfelt\n"
                    f"End with sender's name.\n"
                    f"Email body only, no subject."}]
    }]

    backup_email = (f"Happy Birthday, {recipient_name}! 🎉\n\n"
            f"Wishing you a day filled with joy, laughter, and good memories. "
            f"I'm grateful to have you as my {relationship}.\n\n"
            f"Warm wishes,\n"
            f"{sender_name}")

    try:
        response = client.converse(
                modelId=MODEL_ID,
                messages=messages,
                inferenceConfig=inference_config
            )
        return extract_text(response)
    except ClientError as e:
        print(f"Bedrock ClientError: {e}")
        print("Bedrock throttled: using backup birthday message")

        return backup_email

    except Exception as e:
        print(f"Unexpected Bedrock error: {e}")
        return backup_email

def extract_text(msg):
    output = []

    for x in msg["output"]["message"]["content"]:
        if "text" in x:
            output.append(x["text"])

    return "".join(output)


def get_secret():
    try:
        get_secret_value_response = secrets_client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        raise e

    secret = get_secret_value_response['SecretString']
    return secret

def send_email(to_email, relation, body):
    smtp_creds = json.loads(get_secret())

    msg = EmailMessage()
    msg["From"] = smtp_creds["SMTP_USER"]
    msg["To"] = to_email
    msg["Subject"] = f"Happy Birthday {relation} 🎉!!!"
    msg.set_content(body)
    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
            server.login(smtp_creds["SMTP_USER"], smtp_creds["SMTP_PASSWORD"])
            server.send_message(msg)
    except Exception as e:
        print(f"Error sending email: {e}")

def mark_as_wished(email, created_at):
    try:
        dynamodb.update_item(
            Key={
                "email": email,
                "created_at": created_at,
            },
            UpdateExpression="SET wished = :v",
            ExpressionAttributeValues={":v": True},
        )
    except ClientError as e:
        print(f"Failed to mark birthday as wished: {e}")
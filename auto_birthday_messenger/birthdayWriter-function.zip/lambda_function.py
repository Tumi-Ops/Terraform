from datetime import datetime
import boto3
import json
import os

dynamodb = boto3.resource("dynamodb").Table(os.environ["TABLE_NAME"])

def lambda_handler(event, context):
    print(event)
    body = json.loads(event["body"])
    birthday = body["birthday"]
    month_day = datetime.strptime(birthday, "%Y-%m-%d").strftime("%m-%d")

    dynamodb.put_item(
        Item={
            "email": body["email"],
            "sender_name": body["sender_name"],
            "recipient_name": body["recipient_name"],
            "relationship": body["relationship"],
            "birthday": str(birthday),
            "month_day": str(month_day),
            "created_at": str(datetime.now()),
            "wished": False
        }
    )

    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Saved"})
    }

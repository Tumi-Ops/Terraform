import json
from datetime import datetime

from data_manager import DataManager
from flight_search import FlightSearch
from flight_data import FlightData


def lambda_handler(event, context):
    try:
        body = json.loads(event.get("body", "{}"))

        destination_city = body["destination_city"]
        origin_location = body["origin_location"]
        travel_class = body["travel_class"]
        adults = int(body["adults"])
        children = int(body["children"])
        infants = int(body["infants"])
        from_date = body["from_date"]
        to_date = body["to_date"]

        data_manage = DataManager()
        data_manage.get_iata_codes(
            city=destination_city,
            og_loc=origin_location
        )

        fly_search = FlightSearch(data_manage)
        fly_search.get_flights(
            dep_date=from_date,
            ret_date=to_date,
            ad=adults,
            child=children,
            inf=infants,
            tc=travel_class
        )

        fly_data = FlightData(data_manage, fly_search)

        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps({
                "created_at": datetime.utcnow().isoformat(),
                "structured_flights": fly_data.structured_flights,
                "messages": fly_data.offer_messages
            })
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({
                "error": str(e)
            })
        }

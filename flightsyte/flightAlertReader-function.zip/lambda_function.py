import boto3
import json
import os
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

table = boto3.resource("dynamodb").Table(os.environ["TABLE_NAME"])

def lambda_handler(event, context):
    claims = event["requestContext"]["authorizer"]["jwt"]["claims"]
    email = claims["email"]
    try:
        response = table.query(
            KeyConditionExpression=Key('email').eq(email)
        )
        alerts = response['Items']
        return alerts
    except ClientError as e:
        print(f"Error querying table: {e}")
        return {
            "statusCode": 500,
            "body": json.dumps({"message": "Failed to retrieve items"})
        }
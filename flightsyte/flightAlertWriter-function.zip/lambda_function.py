import boto3
import json
import os

table = boto3.resource("dynamodb").Table(os.environ["TABLE_NAME"])

def lambda_handler(event, context):
    print(event)
    claims = event["requestContext"]["authorizer"]["jwt"]["claims"]
    email = claims["email"]
    if email:
        body = json.loads(event["body"])
        print(body)
        table.put_item(
            Item={
                'email': email,
                'status': "ACTIVE",
                'created_at': body["created_at"],
                'destination_city': body[ "destination_city"],
                'origin_location': body["origin_location"],
                'max_price': body["max_price"],
                'adults': body["adults"],
                'children': body["children"],
                'infants': body["infants"],
                'from_date': str(body["from_date"]),
                'to_date': str(body["to_date"])
            }
        )
    else:
        return {
            "statusCode": 400,
            "body": json.dumps({"message": "Missing email"})
        }
    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Saved"})
    }

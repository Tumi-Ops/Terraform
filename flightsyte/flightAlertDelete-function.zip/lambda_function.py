import boto3
import json
import os

table = boto3.resource("dynamodb").Table(os.environ["TABLE_NAME"])

def lambda_handler(event, context):
    claims = event["requestContext"]["authorizer"]["jwt"]["claims"]
    email = claims["email"]
    if email is None:
        return {"statusCode": 401, "body": "Unauthorized"}
    else:
        body = json.loads(event["body"])
        created_at = body['created_at']
        try:
            response = table.delete_item(
                Key={'email': email,
                    'created_at': created_at}
            )
        except ClientError as e:
            return {
            "statusCode": 404,
            "body": json.dumps({"error": "Alert not found"})
        }
        else:
            return {
            "statusCode": 200,
            "body": json.dumps({"message": "Alert deleted"})
        }

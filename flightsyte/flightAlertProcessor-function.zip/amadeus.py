import os
import json
import boto3
from botocore.exceptions import ClientError

params = None

def get_secrets():
    global params

    if params:
        return params

    client = boto3.client('ssm')
    try:
        response = client.get_parameters(
        Names=[
            'AMS_API_KEY',
            'AMS_API_SECRET'
        ],
        WithDecryption=True)
    except ClientError as e:
        raise e

    params = {
        x["Name"]: x["Value"]
        for x in response["Parameters"]
    }

    return params

get_secrets()
amadeus_token_endpoint = os.environ["AMADEUS_TOKEN_ENDPOINT"]
amadeus_token_params = {
    "grant_type": "client_credentials",
    "client_id": params["AMS_API_KEY"],
    "client_secret": params["AMS_API_SECRET"]
}
amadeus_endpoint = os.environ["AMADEUS_FLIGHT_OFFERS"]
amadeus_cities_endpoint = os.environ["AMADEUS_CITIES_ENDPOINT"]
amadeus_locations_endpoint = os.environ["AMADEUS_LOCATIONS"]
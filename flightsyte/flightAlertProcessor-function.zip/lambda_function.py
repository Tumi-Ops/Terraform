import os
import json
import boto3
import smtplib
import requests
from datetime import datetime
from flight_data import FlightData
from data_manager import DataManager
from flight_search import FlightSearch
from email.message import EmailMessage
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

table = boto3.resource("dynamodb").Table(os.environ["TABLE_NAME"])
client = boto3.client('ssm')

params = None

def lambda_handler(event, context):
    search_flight()
    return {
        'statusCode': 200,
        'body': json.dumps('Flight processor complete!')
    }

def search_flight():
    try:
        alerts = []
        for x in ["ACTIVE", "TRIGGERED"]:
            response = table.query(
                IndexName="GSI1",
                KeyConditionExpression=Key("status").eq(x)
            )
            alerts.extend(response["Items"])

    except ClientError as e:
        print(f"Error querying table: {e}")
        return {
            "statusCode": 500,
            "body": json.dumps({"message": "Failed to retrieve items"})
        }
    print(alerts)
    for x in alerts:
        if x['status'] == "ACTIVE":
            update_item(x["email"], x["created_at"], "TRIGGERED")

        data_manage = DataManager()
        data_manage.get_iata_codes(city=x['destination_city'], og_loc=x['origin_location'])

        fly_search = FlightSearch(data_manage)
        fly_search.get_flights(dep_date=x['from_date'],
                               ret_date=x['to_date'], ad=x['adults'],
                               child=x['children'], inf=x['infants'])

        fly_data = FlightData(data_manage, fly_search)

        structured_flights = fly_data.structured_flights

        for y in structured_flights:
            if y['price'] <= x['max_price']:
                email_body = (f"Good news, a flight to {x['destination_city']} has been found. Here are the details:\n\n"
                  f"Price: R{y['price']}\n"
                  f"Airline: {y['airline']}\n"
                  f"Aircraft: {y['aircraft']}\n"
                  f"Seats Available: {y['seats_available']}\n"
                  f"Travel Class: {y['travel_class']}\n\n"
                  f"Visit this link to book the flight: https://www.google.com/search?q={y['airline']}.\n\n"
                  "Have a safe travel, \nFlightSyte")
                response = send_email(x['email'], x['destination_city'], email_body)
                print(response)
                update_item(x['email'], x['created_at'], "EXPIRED")
            else:
                print(f"No flights found to {x['destination_city']} for user {x['email']}")

def get_email_secrets():
    global params

    if params:
        return params

    try:
        response = client.get_parameters(
        Names=[
            'SMTP_PASSWORD',
            'SMTP_USER'
        ],
        WithDecryption=True)
    except ClientError as e:
        raise e

    params = {
        x["Name"]: x["Value"]
        for x in response["Parameters"]
    }
    return params

def send_email(to_email, destination, body):
    smtp_creds = get_email_secrets()
    msg = EmailMessage()
    msg["From"] = smtp_creds["SMTP_USER"]
    msg["To"] = to_email
    msg["Subject"] = f"Flight to {destination} Found!!!"
    msg.set_content(body)
    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
            server.login(smtp_creds["SMTP_USER"], smtp_creds["SMTP_PASSWORD"])
            server.send_message(msg)
    except Exception as e:
        print(f"Error sending email: {e}")
    return f"Email sent to {to_email}"

def update_item(email, created_at, new_status):
    try:
        response = table.update_item(
            Key={
                "email": email,
                "created_at": created_at
            },
            UpdateExpression="SET #s = :s",
            ExpressionAttributeNames={"#s": "status"},
            ExpressionAttributeValues={":s": new_status}
        )
    except ClientError as e:
        print(e.response["Error"]["Message"])
    else:
        print(f"Item status successfully updated! {response}")
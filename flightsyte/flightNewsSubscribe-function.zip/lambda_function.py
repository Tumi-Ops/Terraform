import os
import json
import boto3

sns = boto3.client('sns')

def lambda_handler(event, context):
    body = json.loads(event['body'])
    try:
        response = sns.subscribe(
            TopicArn=os.environ["SNS_TOPIC"],
            Protocol='email',
            Endpoint=body['email'],
            ReturnSubscriptionArn=True
        )
        return {
            'statusCode': 200,
            'body': json.dumps('Subscription Successful!')
        }
    except Exception as e:
        print(f"Error: {e}")
        return {
            "statusCode": 500,
            "body": json.dumps({"message": f"Error: {e}!"})
        }